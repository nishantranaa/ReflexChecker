package com.nish.reflexchecker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Random;

public class GameActivity extends AppCompatActivity {

    private final Random random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);
        Toast toast = Toast.makeText(this, "GAME ACTIVITY", Toast.LENGTH_LONG);
        toast.show();
        //setup the task descriptions
        setupDescription(R.id.task1, R.array.task1_descriptions);
        setupDescription(R.id.task2, R.array.task2_descriptions);

        Button back = findViewById(R.id.button5); // the button id is used to create an object called start

        Intent intentBackActivity = new Intent(this, MainActivity.class);
        back.setOnClickListener(v -> startActivity(intentBackActivity));


        for (int i = 0; i<5; i++ ){
            addImage();
            addCheckboxes(i);
            addImage();
            addCheckboxes2(i);


        }




    }


    private void setupDescription(int taskID, int arrayID) {
        TextView task = findViewById(taskID);
        String[] descriptions = getResources().getStringArray(arrayID);
        int i = random.nextInt(descriptions.length);
        task.setText(descriptions[i]);


    }

    private static final int[] drawables = {
      R.drawable.baseline_android_black_48,
      R.drawable.baseline_developer_mode_black_48,
      R.drawable.baseline_laptop_chromebook_black_48
    };

    private void addImage(){
        ViewGroup gameRows = findViewById(R.id.game_rows);
        getLayoutInflater().inflate(R.layout.image_layout, gameRows);
        View lastChild = gameRows.getChildAt(gameRows.getChildCount()-1);
        ImageView image = lastChild.findViewById(R.id.image);
        int index = random.nextInt(drawables.length);
        image.setImageDrawable(getResources().getDrawableForDensity(drawables[index], 0));


    }
    private void addCheckboxes(int arrayID){
       ViewGroup checkBox_1 = findViewById(R.id.game_rows);
       getLayoutInflater().inflate(R.layout.checkboxes_layout, checkBox_1);
       View lastChild = checkBox_1.getChildAt(arrayID);




    }

    private void addCheckboxes2(int arrayID){
        ViewGroup checkBox_1 = findViewById(R.id.game_rows);
        getLayoutInflater().inflate(R.layout.checkboxes_layout2, checkBox_1);
        View lastChild = checkBox_1.getChildAt(arrayID);

    }
}